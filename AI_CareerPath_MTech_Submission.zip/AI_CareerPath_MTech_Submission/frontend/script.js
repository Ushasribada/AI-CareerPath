/* =====================================================
   AI CAREER SKILL GAP ANALYZER
   Backend Connected Version
   ===================================================== */


/* ================= BACKEND API ================= */

const API_BASE_URL =
    "https://YOUR-RENDER-SERVICE.onrender.com";

const API_URL =
    API_BASE_URL + "/analyze-file";


/* ================= SCROLL ================= */

function scrollToAnalysis() {

    document
        .getElementById("analysis")
        .scrollIntoView({
            behavior: "smooth"
        });
}


/* ================= FILE SELECTION ================= */

document
    .getElementById("resumeFile")
    .addEventListener("change", function () {

        const file = this.files[0];

        if (file) {

            document
                .getElementById("fileName")
                .textContent =
                "Selected file: " + file.name;
        }
    });


/* ================= HELPER FUNCTION ================= */

function createSkillBadge(
    skill,
    className = "skill"
) {

    const span =
        document.createElement("span");

    span.className = className;

    span.textContent = skill;

    return span;
}


/* =====================================================
   ANALYZE RESUME
   ===================================================== */

async function analyzeResume() {

    const fileInput =
        document.getElementById("resumeFile");


    /* ================= CHECK FILE ================= */

    if (!fileInput.files.length) {

        alert(
            "Please upload your resume first."
        );

        return;
    }


    const file =
        fileInput.files[0];


    /* ================= CHECK FORMAT ================= */

    const allowedTypes = [
        ".pdf",
        ".doc",
        ".docx"
    ];

    const fileName =
        file.name.toLowerCase();

    const validFile =
        allowedTypes.some(
            extension =>
                fileName.endsWith(extension)
        );


    if (!validFile) {

        alert(
            "Please upload a PDF or DOC/DOCX resume."
        );

        return;
    }


    /* ================= SHOW LOADING ================= */

    const analyzeButton =
        document.querySelector(
            'button[onclick="analyzeResume()"]'
        );


    if (analyzeButton) {

        analyzeButton.disabled = true;

        analyzeButton.textContent =
            "Analyzing Resume...";
    }


    try {

        /* ================= CREATE FORM DATA ================= */

        const formData =
            new FormData();

        formData.append(
            "resume",
            file
        );


        /* ================= SEND RESUME TO FLASK ================= */

        const response =
            await fetch(
                API_URL,
                {
                    method: "POST",
                    headers: {
                        "ngrok-skip-browser-warning": "true"
                    },
                    body: formData
                }
            );


        /* ================= READ RESPONSE ================= */

        const data =
            await response.json();

        console.log(
            "Backend Response:",
            data
        );


        /* ================= ERROR CHECK ================= */

        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.error ||
                "Resume analysis failed."
            );
        }


        /* ================= STORE RESULT ================= */

        window.analysisResult =
            data;


        const candidate =
            data.candidate;

        const recommendation =
            data.recommendation;


        /* ================= SHOW DASHBOARD ================= */

        document
            .getElementById("dashboard")
            .style.display = "block";


        /* ================= CANDIDATE NAME ================= */

        let candidateName =
            file.name
                .replace(/\.[^/.]+$/, "")
                .replace(/[_-]/g, " ");


        if (!candidateName.trim()) {

            candidateName =
                "Resume Candidate";
        }


        const candidateNameElement =
            document.getElementById(
                "candidateName"
            );


        if (candidateNameElement) {

            candidateNameElement.textContent =
                candidateName;
        }


        /* ================= SKILL COUNT ================= */

        const skillCountElement =
            document.getElementById(
                "skillCount"
            );


        if (skillCountElement) {

            skillCountElement.textContent =
                candidate.skill_count +
                " Skills";
        }


        /* ================= RECOMMENDED ROLE ================= */

        const recommendedRole =
            recommendation.job_role;


        const roleCard =
            document.getElementById(
                "roleCard"
            );


        if (roleCard) {

            roleCard.textContent =
                recommendedRole;
        }


        const recommendedRoleElement =
            document.getElementById(
                "recommendedRole"
            );


        if (recommendedRoleElement) {

            recommendedRoleElement.textContent =
                recommendedRole;
        }


        const finalRole =
            document.getElementById(
                "finalRole"
            );


        if (finalRole) {

            finalRole.textContent =
                recommendedRole;
        }


        /* ================= DETECTED SKILLS ================= */

        const detectedContainer =
            document.getElementById(
                "detectedSkills"
            );


        if (detectedContainer) {

            detectedContainer.innerHTML = "";


            candidate.skills.forEach(
                function (skill) {

                    detectedContainer.appendChild(
                        createSkillBadge(
                            skill
                        )
                    );
                }
            );
        }


        /* ================= MATCHING SKILLS ================= */

        const matchingContainer =
            document.getElementById(
                "matchingSkills"
            );


        if (matchingContainer) {

            matchingContainer.innerHTML = "";


            recommendation.matching_skills.forEach(
                function (skill) {

                    matchingContainer.appendChild(
                        createSkillBadge(
                            skill,
                            "skill match"
                        )
                    );
                }
            );
        }


        /* ================= MISSING SKILLS ================= */

        const missingContainer =
            document.getElementById(
                "missingSkills"
            );


        if (missingContainer) {

            missingContainer.innerHTML = "";


            recommendation.missing_skills.forEach(
                function (skill) {

                    missingContainer.appendChild(
                        createSkillBadge(
                            skill,
                            "skill missing"
                        )
                    );
                }
            );
        }


        /* ================= MATCH PERCENTAGE ================= */

        const matchPercentage =
            recommendation.skill_match;


        const matchElement =
            document.getElementById(
                "matchPercentage"
            );


        if (matchElement) {

            matchElement.textContent =
                matchPercentage + "%";
        }


        /* ================= PROGRESS BAR ================= */

        const progressBar =
            document.getElementById(
                "progressBar"
            );


        if (progressBar) {

            progressBar.style.width =
                "0%";


            setTimeout(
                function () {

                    progressBar.style.width =
                        matchPercentage + "%";

                },
                200
            );
        }


        /* ================= MARKET DEMAND ================= */

        const marketDemand =
            document.getElementById(
                "marketDemand"
            );


        if (marketDemand) {

            marketDemand.textContent =
                recommendation.market_demand +
                "%";
        }


        /* ================= EXPLAINABLE AI ================= */

        const explanation =
            document.getElementById(
                "explanation"
            );


        if (explanation) {

            explanation.textContent =
                recommendation.explanation;
        }


        /* =====================================================
           TOP CAREER RECOMMENDATIONS
           ===================================================== */

        displayTopRecommendations(
            data.top_recommendations
        );


        /* =====================================================
           PERSONALIZED LEARNING ROADMAP
           ===================================================== */

        displayLearningRoadmap(
            data.learning_roadmap
        );


        /* =====================================================
           REAL JOB MARKET SKILL TRENDS
           ===================================================== */

        await loadMarketTrends();


        /* ================= SUCCESS MESSAGE ================= */

        console.log(
            "Resume analysis completed successfully."
        );


        /* ================= SCROLL TO DASHBOARD ================= */

        setTimeout(
            function () {

                document
                    .getElementById("dashboard")
                    .scrollIntoView({
                        behavior: "smooth"
                    });

            },
            300
        );


    } catch (error) {

        console.error(
            "Analysis Error:",
            error
        );


        alert(
            "Unable to analyze the resume.\n\n" +
            error.message
        );


    } finally {

        /* ================= RESTORE BUTTON ================= */

        if (analyzeButton) {

            analyzeButton.disabled =
                false;

            analyzeButton.textContent =
                "Analyze Resume";
        }
    }
}


/* =====================================================
   MARKET TRENDS
   ===================================================== */

async function loadMarketTrends() {

    try {

        console.log(
            "Loading real job market trends..."
        );


        const response =
            await fetch(
                API_BASE_URL + "/market-trends",
                {
                    method: "GET",

                    headers: {
                        "ngrok-skip-browser-warning": "true"
                    }
                }
            );


        const data =
            await response.json();


        console.log(
            "Market Trends Response:",
            data
        );


        if (
            !response.ok ||
            !data.success
        ) {

            throw new Error(
                data.error ||
                "Unable to load market trends."
            );
        }


        /* Store market trend data */

        window.marketTrends =
            data;


        /* Display trends */

        displayMarketTrends(
            data.trends
        );


    } catch (error) {

        console.error(
            "Market Trends Error:",
            error
        );


        const container =
            document.getElementById(
                "marketTrendsContainer"
            );


        if (container) {

            container.innerHTML =
                "<p>Unable to load market trends.</p>";
        }
    }
}


/* =====================================================
   DISPLAY MARKET TRENDS
   ===================================================== */

function displayMarketTrends(
    trends
) {

    const container =
        document.getElementById(
            "marketTrendsContainer"
        );


    if (!container) {

        console.log(
            "Market trends container not found."
        );

        return;
    }


    if (
        !trends ||
        trends.length === 0
    ) {

        container.innerHTML =
            "<p>No market trend data available.</p>";

        return;
    }


    /* Find highest demand */

    const maxDemand =
        Math.max(
            ...trends.map(
                item =>
                    item.demand_percentage
            )
        );


    /* Clear old content */

    container.innerHTML = "";


    /* Create trend cards */

    trends.forEach(
        function (item, index) {

            const trendItem =
                document.createElement(
                    "div"
                );


            trendItem.className =
                "trend-item";


            const barWidth =
                (
                    item.demand_percentage /
                    maxDemand
                ) * 100;


            trendItem.innerHTML = `
                <div class="trend-label">

                    <strong>
                        ${index + 1}.
                        ${item.skill}
                    </strong>

                    <span>
                        ${item.job_count}
                        jobs
                        •
                        ${item.demand_percentage.toFixed(2)}%
                    </span>

                </div>


                <div class="trend-background">

                    <div
                        class="trend-progress"
                        style="width:${barWidth}%">
                    </div>

                </div>
            `;


            container.appendChild(
                trendItem
            );
        }
    );
}


/* =====================================================
   TOP CAREER RECOMMENDATIONS
   ===================================================== */

function displayTopRecommendations(
    recommendations
) {

    const container =
        document.getElementById(
            "recommendationsContainer"
        );


    if (!container) {

        console.log(
            "Recommendation container not found. " +
            "Backend recommendations are still available in window.analysisResult."
        );

        return;
    }


    container.innerHTML = "";


    if (
        !recommendations ||
        recommendations.length === 0
    ) {

        container.innerHTML =
            "<p>No career recommendations available.</p>";

        return;
    }


    recommendations.forEach(
        function (item, index) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "recommendation-card";


            card.innerHTML = `
                <h3>
                    ${index + 1}.
                    ${item.job_role}
                </h3>

                <p>
                    <strong>
                        Skill Match:
                    </strong>
                    ${item.skill_match}%
                </p>

                <p>
                    <strong>
                        Market Demand:
                    </strong>
                    ${item.market_demand}%
                </p>

                <p>
                    <strong>
                        Dynamic Score:
                    </strong>
                    ${item.dynamic_score}
                </p>

                <p>
                    ${item.explanation}
                </p>
            `;


            container.appendChild(
                card
            );
        }
    );
}


/* =====================================================
   PERSONALIZED LEARNING ROADMAP
   ===================================================== */

function displayLearningRoadmap(
    roadmap
) {

    const container =
        document.getElementById(
            "learningRoadmap"
        );


    if (!container) {

        console.log(
            "Learning roadmap container not found. " +
            "Backend roadmap is still available in window.analysisResult."
        );

        return;
    }


    container.innerHTML = "";


    if (
        !roadmap ||
        roadmap.length === 0
    ) {

        container.innerHTML =
            "<p>No major skill gaps identified.</p>";

        return;
    }


    roadmap.forEach(
        function (item, index) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "roadmap-item";


            card.innerHTML = `
                <h3>
                    ${index + 1}.
                    ${item.skill}
                </h3>

                <p>
                    Market Demand:
                    ${item.market_demand}%
                </p>

                <p>
                    Priority:
                    ${Number(
                        item.priority
                    ).toFixed(2)}
                </p>
            `;


            container.appendChild(
                card
            );
        }
    );
}


/* =====================================================
   DEBUG FUNCTION
   ===================================================== */

function showAnalysisData() {

    console.log(
        "Current Analysis Result:",
        window.analysisResult
    );


    console.log(
        "Current Market Trends:",
        window.marketTrends
    );
}